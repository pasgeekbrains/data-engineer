
/*
   Cоздаем схему ts
*/
create schema ts;


-- Таблица проектов --
CREATE SEQUENCE ts.project_id_seq;

CREATE TABLE ts.project
(
    id    bigint      NOT NULL DEFAULT nextval('ts.project_id_seq'),
    mnemo varchar(50) NOT NULL,
    note  varchar(255),
        PRIMARY KEY (id),
    UNIQUE (note)
)

insert into ts.project (mnemo) values ('Социальная сеть');

-- Таблица статусов набора параметров
CREATE TABLE ts.status
(
    id    bigint,
    mnemo varchar(50) NOT NULL,
    note  varchar(255),
        PRIMARY KEY (id),
    UNIQUE (note)
)

insert into ts.status(id, mnemo) values (1, 'Не доступен')
insert into ts.status(id, mnemo) values (2, 'Доступен')



-- Таблица набор параметров
CREATE SEQUENCE ts.param_set_id_seq;

CREATE TABLE ts.param_set (
  id bigint NOT NULL DEFAULT nextval('ts.param_set_id_seq'),
  mnemo varchar(50) NOT NULL,
  project_id bigint NOT NULL,
  status_id bigint NOT NULL,
  sql_query text not null ,
  time_point varchar(20) not null ,
  time_point_fmt varchar(10) not null ,
  indicator varchar(20) not null ,
  create_at timestamp not null DEFAULT CURRENT_TIMESTAMP,
  UNIQUE_str varchar(300),
  PRIMARY KEY (id),
  UNIQUE(UNIQUE_str)
)

alter table ts.param_set add CONSTRAINT fk_param_set_project_id FOREIGN KEY (project_id) REFERENCES ts.project (id)
alter table ts.param_set add CONSTRAINT fk_param_set_status_id FOREIGN KEY (status_id) REFERENCES ts.status (id)

CREATE INDEX idx_param_set_project_id ON ts.param_set (project_id);
CREATE INDEX idx_param_set_status_id ON ts.param_set (status_id);

CREATE INDEX idx_param_set_UNIQUE_str ON ts.param_set (UNIQUE_str);


select * from ts.project
;
insert into ts.param_set(mnemo, project_id, status_id, sql_query, time_point, time_point_fmt, indicator)
values
('Длительность создания поста', 1, 1, 'sadsad', 'post_date', 'month', 'post_interval' )


-- Таблица, описывающая поля временного ряда - нужно для мэппинга
CREATE TABLE ts.time_series_field
(
  id varchar(20),
  field_type varchar(100) NOT NULL,
  PRIMARY KEY (id)
)

insert into ts.time_series_field(id, field_type) values ('s1', 'Строка 255 символов')

insert into ts.time_series_field(id, field_type) values ('s2', 'Строка 255 символов')
insert into ts.time_series_field(id, field_type) values ('s3', 'Строка 255 символов')
insert into ts.time_series_field(id, field_type) values ('s4', 'Строка 255 символов')
insert into ts.time_series_field(id, field_type) values ('s5', 'Строка 255 символов')

insert into ts.time_series_field(id, field_type) values ('n1', 'Число')
insert into ts.time_series_field(id, field_type) values ('n2', 'Число')
insert into ts.time_series_field(id, field_type) values ('n3', 'Число')
insert into ts.time_series_field(id, field_type) values ('n4', 'Число')
insert into ts.time_series_field(id, field_type) values ('n5', 'Число')

insert into ts.time_series_field(id, field_type) values ('d1', 'Дата')
insert into ts.time_series_field(id, field_type) values ('d2', 'Дата')
insert into ts.time_series_field(id, field_type) values ('d3', 'Дата')
insert into ts.time_series_field(id, field_type) values ('d4', 'Дата')
insert into ts.time_series_field(id, field_type) values ('d5', 'Дата')


select *
       from ts.time_series_field

-- Список полей набора параметров
CREATE SEQUENCE ts.param_set_field_id_seq;

CREATE TABLE ts.param_set_field (
  id bigint NOT NULL DEFAULT nextval('ts.param_set_field_id_seq'),
  param_set_id bigint NOT NULL,
  field_name varchar(20) not null,
  field_comment varchar(255) ,
  time_series_field_id varchar(20) not null ,
  PRIMARY KEY (id),
  UNIQUE(param_set_id, field_name),
  UNIQUE(param_set_id, time_series_field_id)
)

alter table ts.param_set_field add CONSTRAINT fk_param_set_field_param_set_id FOREIGN KEY (param_set_id) REFERENCES ts.param_set (id)
alter table ts.param_set_field add CONSTRAINT fk_param_set_ts_field_id FOREIGN KEY (time_series_field_id) REFERENCES ts.time_series_field (id)

CREATE INDEX idx_param_set_field_param_set_id ON ts.param_set_field (param_set_id);
CREATE INDEX idx_param_set_ts_field_id ON ts.param_set_field (time_series_field_id);


-- Список полей агрегатов набора параметров
CREATE SEQUENCE ts.param_set_field_agg_id_seq;

CREATE TABLE ts.param_set_field_agg (
  id bigint NOT NULL DEFAULT nextval('ts.param_set_field_agg_id_seq'),
  param_set_id bigint NOT NULL,
  field_sql varchar(100) not null,
  field_comment varchar(255),
  PRIMARY KEY (id),
  UNIQUE(param_set_id, field_sql)
)

alter table ts.param_set_field_agg add CONSTRAINT fk_param_set_field_agg_param_set_id FOREIGN KEY (param_set_id) REFERENCES ts.param_set (id)
CREATE INDEX idx_param_set_field_agg_param_set_id ON ts.param_set_field_agg(param_set_id);


alter table ts.param_set_field add CONSTRAINT fk_param_set_field_param_set_id FOREIGN KEY (param_set_id) REFERENCES ts.param_set (id)


-- Таблица - Элементы набора параметров
CREATE SEQUENCE ts.param_set_elem_id_seq;

CREATE TABLE ts.param_set_elem (
  id bigint NOT NULL DEFAULT nextval('ts.param_set_elem_id_seq'),
  param_set_id bigint NOT NULL,
  level_no int not null,
  UNIQUE_str varchar(500),
  PRIMARY KEY (id),
  UNIQUE(param_set_id, level_no),
  UNIQUE(UNIQUE_str)
)

alter table ts.param_set_elem add CONSTRAINT fk_param_set_elem_param_set_id FOREIGN KEY (param_set_id) REFERENCES ts.param_set (id)

CREATE INDEX idx_param_set_elem_param_set_id ON ts.param_set_elem (param_set_id);


-- Таблица - Временные ряды --
CREATE SEQUENCE ts.time_series_id_seq;

drop TABLE ts.time_series

CREATE TABLE ts.time_series
(
  id bigint NOT NULL DEFAULT nextval('ts.time_series_id_seq'),
  param_set_elem_id bigint NOT NULL,
  time_point timestamp not null,
  count_indicator bigint not null,
  min_indicator numeric not null,
  avg_indicator numeric not null,
  max_indicator numeric not null,
  percentile_cont_0_5_indicator numeric not null,
  percentile_cont_0_1_indicator numeric not null,
  percentile_cont_0_9_indicator numeric not null,
  stddev_pop_indicator numeric not null,
  stddev_samp_indicator numeric not null,
  var_pop_indicator numeric not null,
  var_samp_indicator numeric not null,
  mode_indicator numeric not null,
  s1 varchar(255),
  s2 varchar(255),
  s3 varchar(255),
  s4 varchar(255),
  s5 varchar(255),
  n1 numeric,
  n2 numeric,
  n3 numeric,
  n4 numeric,
  n5 numeric,
  d1 timestamp,
  d2 timestamp,
  d3 timestamp,
  d4 timestamp,
  d5 timestamp,
  PRIMARY KEY (id)
)



alter table ts.time_series add CONSTRAINT fk_time_series_param_set_elem_id FOREIGN KEY (param_set_elem_id) REFERENCES ts.param_set_elem (id)

CREATE INDEX idx_time_series_param_set_elem_id ON ts.time_series (param_set_elem_id);


insert into ts.param_set_elem(param_set_id, level_no) values (1, 1)

insert into ts.param_set_field(param_set_id, field_name, field_comment, time_series_field_id)
values
(1, 'gender', 'Пол', 's1');

insert into ts.param_set_field(param_set_id, field_name, field_comment, time_series_field_id)
values
(1, 'age', 'Возраст', 'n1');


insert into ts.param_set_field(param_set_id, field_name, field_comment, time_series_field_id)
values
(1, 'hometown', 'Город', 's2');

commit;

-- Таблица - Допустимые поля для элемента набора параметров
CREATE TABLE ts.PARAM_SET_ELEM_FIELD
(
  PARAM_SET_ELEM_ID bigint,
  PARAM_SET_FIELD_ID bigint,
  PRIMARY KEY (PARAM_SET_ELEM_ID, PARAM_SET_FIELD_ID)
)

alter table ts.PARAM_SET_ELEM_FIELD add CONSTRAINT fk_PARAM_SET_ELEM_FIELD_PARAM_SET_ELEM_id FOREIGN KEY (PARAM_SET_ELEM_FIELD) REFERENCES ts.param_set_ELEM (id)

alter table ts.PARAM_SET_ELEM_FIELD add CONSTRAINT fk_PARAM_SET_ELEM_FIELD_PARAM_SET_FIELD_ID FOREIGN KEY (PARAM_SET_FIELD_ID) REFERENCES ts.param_set_field (id)

CREATE INDEX idx_PARAM_SET_ELEM_FIELD_PARAM_SET_FIELD_ID ON ts.PARAM_SET_ELEM_FIELD (PARAM_SET_FIELD_ID);

CREATE INDEX idx_PARAM_SET_ELEM_FIELD_PARAM_SET_ELEM_id ON ts.PARAM_SET_ELEM_FIELD (param_set_elem_id);



insert into ts.param_set_field_agg(param_set_id, field_sql, field_comment)
values
(1,'count(@Indicator)', 'Количество')

insert into ts.param_set_field_agg(param_set_id, field_sql, field_comment)
values
(1,'max(@Indicator)', 'Максимум')

insert into ts.param_set_field_agg(param_set_id, field_sql, field_comment)
values
(1,'avg(@Indicator)', 'Среднее')

insert into ts.param_set_field_agg(param_set_id, field_sql, field_comment)
values
(1,'min(@Indicator)', 'Минимум')

insert into ts.param_set_field_agg(param_set_id, field_sql, field_comment)
values
(1,'percentile_cont(0.5) WITHIN GROUP (ORDER BY @Indicator)', 'Мединана')

insert into ts.param_set_field_agg(param_set_id, field_sql, field_comment)
values
(1,'percentile_cont(0.1) WITHIN GROUP (ORDER BY @Indicator)', 'Процентиль 0.1')

insert into ts.param_set_field_agg(param_set_id, field_sql, field_comment)
values
(1,'percentile_cont(0.9) WITHIN GROUP (ORDER BY @Indicator)', 'Процентиль 0.9')


insert into ts.param_set_field_agg(param_set_id, field_sql, field_comment)
values
(1,'stddev_pop(@Indicator)::numeric', 'Стандартное отклонение по генеральной совокупности входных значений')

insert into ts.param_set_field_agg(param_set_id, field_sql, field_comment)
values
(1,'stddev_samp(@Indicator)::numeric', 'стандартное отклонение по выборке входных значений')

insert into ts.param_set_field_agg(param_set_id, field_sql, field_comment)
values
(1,'var_pop(@Indicator)::numeric', 'дисперсия для генеральной совокупности входных значений (квадрат стандартного отклонения)')

insert into ts.param_set_field_agg(param_set_id, field_sql, field_comment)
values
(1,'var_samp(@Indicator)::numeric', 'дисперсия по выборке для входных значений (квадрат отклонения по выборке)')


insert into ts.param_set_field_agg(param_set_id, field_sql, field_comment)
values
(1,'mode() WITHIN GROUP (ORDER BY @Indicator)', 'возвращает значение, наиболее часто встречающееся во входных данных')



-- Таблица - Временной ряд: Поля агрегаты
CREATE TABLE ts.time_series_field_agg
(
  id varchar(20),
  field_comment varchar(100) NOT NULL,
  PRIMARY KEY (id)
)

insert into ts.time_series_field_agg values ('count_indicator', 'Количество')
insert into ts.time_series_field_agg values ('min_indicator', 'Минимум')
insert into ts.time_series_field_agg values ('avg_indicator', 'Среднее')
insert into ts.time_series_field_agg values ('max_indicator', 'Максимум')

insert into ts.time_series_field_agg values ('percentile_cont_0_5_indicator', 'Медиана')
insert into ts.time_series_field_agg values ('percentile_cont_0_1_indicator', 'Процентиль 0.1')
insert into ts.time_series_field_agg values ('percentile_cont_0_9_indicator', 'Процентиль 0.9')

insert into ts.time_series_field_agg values ('stddev_pop_indicator', 'Стандартное отклонение по генеральной совокупности входных значений')
insert into ts.time_series_field_agg values ('stddev_samp_indicator', 'Стандартное отклонение по выборке входных значений')


insert into ts.time_series_field_agg values ('var_pop_indicator', 'Дисперсия для генеральной совокупности входных значений (квадрат стандартного отклонения')
insert into ts.time_series_field_agg values ('var_samp_indicator', 'Дисперсия по выборке для входных значений (квадрат отклонения по выборке)')

insert into ts.time_series_field_agg values ('mode_indicator', 'Возвращает значение, наиболее часто встречающееся во входных данных')

commit

ALTER TABLE ts.time_series_field_agg ALTER COLUMN id TYPE varchar(30);





-- Какие-то доп поля, которые потребовались по ходу разработки
alter table ts.param_set_elem add column SQL_INS_QUERY text

alter table ts.param_set_field_agg add column time_series_field_agg_id varchar(30)

alter table ts.param_set_field_agg alter column time_series_field_agg_id SET NOT NULL

ALTER TABLE ts.param_set_field_agg
ADD UNIQUE (param_set_id, time_series_field_agg_id)


alter table ts.param_set_field_agg add CONSTRAINT fk_param_set_field_agg_time_series_field_agg_id FOREIGN KEY (time_series_field_agg_id) REFERENCES ts.time_series_field_agg (id)

CREATE INDEX idx_param_set_field_agg_time_series_field_agg_id ON ts.PARAM_SET_FIELD_agg (time_series_field_agg_id);

---------------------------------------------------------------------------------

/*
3-и процедуры для работы с этим интрументом
*/

-- 1 - При открытии набора параметров
-- Нужно в случае, если требуется что-то изменить: поправить SQL запрос, изменить уровни ...
-- Соответственно, очищаем все расчитанные временные ряды, связанные с этим набором параметов и подготовренные для их расчета sql pfghjcs
do $$
begin
	call ts.params_set_open(pparamsetid := 1);
	commit;
end
$$;


-- 2 При закрытии набора параметров
-- На основе данных, связанных с набором парамета для каждого еего элемента генерируем SQL запрос и сохраняем его в виде текста
do $$
begin
	call ts.params_set_close(pparamsetid := 1);
	commit ;
end;
$$;

-- Пример получившегося SQL запроса, который был сгенерирован
insert into ts.time_series(param_set_elem_id, time_point, count_indicator, min_indicator, avg_indicator, max_indicator, percentile_cont_0_5_indicator, percentile_cont_0_1_indicator, percentile_cont_0_9_indicator, stddev_pop_indicator, stddev_samp_indicator, var_pop_indicator, var_samp_indicator, mode_indicator, s1)
select 1 as param_set_elem_id
     , date_trunc('month', k.created_at)::timestamp as time_point
     , count(*) as count_indicator
     , min(post_interval)::numeric as min_indicator
     , avg(post_interval)::numeric as avg_indicator
     , max(post_interval)::numeric as max_indicator
     , percentile_cont(0.5) WITHIN GROUP (ORDER BY post_interval) as percentile_cont_0_5_indicator
     , percentile_cont(0.1) WITHIN GROUP (ORDER BY post_interval) as percentile_cont_0_1_indicator
     , percentile_cont(0.9) WITHIN GROUP (ORDER BY post_interval) as percentile_cont_0_9_indicator
     , stddev_pop(post_interval)::numeric as stddev_pop_indicator
     , stddev_samp(post_interval)::numeric as stddev_samp_indicator
     , var_pop(post_interval)::numeric as var_pop_indicator
     , var_samp(post_interval)::numeric as var_samp_indicator
     , mode() WITHIN GROUP (ORDER BY post_interval) as mode_indicator
     , gender
  from (
           select extract(epoch from ld_created_at - created_at)/3600 as post_interval
                , r.created_at as post_date
                , EXTRACT(year FROM age(r.birthday)) as age
                , r.gender
                , r.hometown
           from (select p.created_at
                      , lead(p.created_at) over (partition by p.user_id order by p.created_at) as ld_created_at
                      , u.birthday
                      , u.gender
                      , u.hometown
                 from snet.posts p
                          join snet.users u on (u.id = p.user_id)
                ) r
           where r.ld_created_at is not null
       ) k
  group by  date_trunc('month', k.created_at)::timestamp, gender
  order by 1, gender


-- 3- Заполняем временной ряд для указанного набора параметров
-- Берем сохраненные в виде текста SQL запросы и отправляем их на исполнение.
do $$
begin
	call ts.fill_time_series(pparamsetelemid := 1);
	commit ;
end
$$;






