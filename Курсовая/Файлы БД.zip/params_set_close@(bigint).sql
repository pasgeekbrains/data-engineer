create procedure params_set_close(pparamsetid bigint)
    language plpgsql
as
$$
DECLARE
  
  vIndicator    ts.param_set.indicator%type;
  vTimePoint    ts.param_set.time_point%type;
  vTimePointFmt ts.param_set.time_point_fmt%type;
  vSqlQuery     ts.param_set.sql_query%type;
  vStatusId     ts.param_set.status_id%type;
  vPrjMnemo     ts.project.mnemo%type;  

begin


  begin
    select ps.time_point_fmt, ps.status_id, p.mnemo
         , ps.sql_query, ps.time_point,ps.indicator
      into STRICT vTimePointFmt, vStatusId, vPrjMnemo
         , vSqlQuery, vTimePoint, vIndicator   
      from ts.param_set ps
         , ts.project p
     where ps.id = pParamSetId
       and p.id = ps.project_id;
  exception
    when no_data_found then
       raise exception 'Не удалось найти Набор параметров с Id= %', pParamSetId;
  end;

  if vStatusId = 2 then
    raise exception 'Набор параметров уже доступен к использованию';
  end if;

  if vTimePointFmt is null then
    raise exception 'Не указан формат временной точки (month, day...)';
  end if;
  
  if vSqlQuery is null then
       raise exception 'Не указан формат SQL запрос';
  end if;

  if vTimePoint is null then
    raise exception 'Не указано названия поля временной точки';
  end if;

  if vIndicator is null then
    raise exception 'Не указано название поля индекатора';
  end if;

  update ts.param_set_elem e
    set unique_str = (select '{' || string_agg(f.field_comment, ',' order by f.id) || '}'
                          from ts.param_set_elem_field as fe
                               join ts.param_set_field f on (f.id = fe.param_set_field_id)
                         where fe.param_set_elem_id = e.id
                       )
      , sql_ins_query = ts.get_sql_ins_query(e.id)
  where e.param_set_id = pParamSetId;

  update ts.param_set p
     set unique_str = vPrjMnemo || ': ' || p.mnemo || '(' || p.time_point_fmt || ')'
       , status_id = 2
   where p.id = pParamSetId;
  

end
$$;

alter procedure params_set_close(bigint) owner to admin;

