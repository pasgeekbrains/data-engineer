/*
   Cоздаем схему snet, где будут 3-и таблицы: Пользователи(users), Посты(posts), Лайки к постам(likes_posts)
*/
create schema snet;


-- Пользователи(users)
CREATE SEQUENCE snet.user_id_seq;

CREATE TABLE snet.users (
  id bigint NOT NULL DEFAULT nextval('snet.user_id_seq'),
  firstname varchar(50) NOT NULL,
  lastname varchar(50),
  email varchar(120),
  phone varchar(20),
  birthday date,
  hometown varchar(100),
  gender char(1),
  photo_id bigint,
  create_at timestamp DEFAULT CURRENT_TIMESTAMP,
  pass char(40),
  PRIMARY KEY (id),
  UNIQUE(email),
  UNIQUE(phone)
);

/*
Тут было много инсертов(310) из гененирилки
*/


select count(*)
  from snet.users




--Посты(posts)
CREATE SEQUENCE snet.posts_id_seq;

CREATE TABLE snet.posts
(
  id bigint NOT NULL DEFAULT nextval('snet.posts_id_seq'),
  user_id bigint NOT NULL,
  post text,
  created_at timestamp DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_posts_user_id FOREIGN KEY (user_id) REFERENCES snet.users (id)
);

-- Гененируем посты (в таблицу posts изначельно вставил пару записей через IDE, затем запустил несколько раз этот инсерт)
INSERT INTO snet.posts (user_id,post)
select case user_id
        when 0 then 1
        else user_id
       end
     , post
  from (
           select round(random() * 310) as user_id
                , 'Бла Бла Бла'         as post
           from snet.posts p
       ) r
;

-- В общем, нагенерил:
select * --count(*) -- 348160
  from snet.posts p




------------------------------------------------
-- Теперь нужно раскидать посты во времени в интервале от 01.01.2020 по 31.12.2020 - нужно изменить created_at

-- Для этого создаем вспомагательную таблицу, куда с минута запишем весь период
-- Затем напишем ф-ю, которая по переданному числу вернет дату со временем (число быдем генерить случайнам образом)
CREATE TABLE snet.date_min_tmp
(
  id bigint,
  date_min timestamp not null,
  PRIMARY KEY (id)
)

-- Заполняем таблицу
insert into snet.date_min_tmp
select row_number() over (order by r.day) as id , r.day as date_min
  from (
           SELECT *
           FROM generate_series
                    ('2020-01-01'::timestamp
                    , '2020-12-31'::timestamp
                    , '1 min'::interval) day
       ) r

commit
-- Итого, получилось 525601 записей



-- Ф-я, которая будет возвращать дату-время
CREATE FUNCTION snet.get_date(integer) RETURNS timestamp AS $$
    SELECT t.date_min from snet.date_min_tmp t where t.id = $1 ;
$$ LANGUAGE SQL;


select snet.get_date(25) -- Проверяем, что работает

select count(*) -- 525601
  from snet.date_min_tmp
;

--Раскидываем посты во времени изменяя created_at
update snet.posts
   set updated_at = null -- Считаем, что посты не менялись
       created_at = snet.get_date(round(random() * 525601)::integer)



-- Тут что-то тормозило собрал статистику, план изменился в лучшую сторону
ANALYZE snet.users  -- posts


---------------------------------------


-- Таблица с лайками к постам (likes_posts)

CREATE SEQUENCE snet.likes_posts_id_seq;


CREATE TABLE snet.likes_posts
(
  id bigint NOT NULL DEFAULT nextval('snet.likes_posts_id_seq'),
  post_id bigint NOT NULL,
  user_id bigint  NOT NULL,
  created_at timestamp NOT NULL,
  PRIMARY KEY (id),
  UNIQUE (user_id,post_id),
  CONSTRAINT fk_likes_posts_user_id FOREIGN KEY (user_id) REFERENCES snet.users (id),
  CONSTRAINT fk_likes_posts_post_id FOREIGN KEY (post_id) REFERENCES snet.posts (id)
)

CREATE INDEX idx_likes_posts_user_id ON snet.likes_posts (user_id);
CREATE INDEX idx_likes_posts_post_id ON snet.likes_posts (post_id);



-- Тут pl_sql -й блок, генерирующий лайки с учетом времени
do $$
<<first_block>>
declare
  vPostId bigint;
  vUserId bigint;
  vPostDate timestamp;
  vLikeDate timestamp;
  vPostUserId bigint;
  vRandomPostId bigint;
  arow record;
begin
    FOR arow IN
          SELECT rr::int as fld FROM generate_series(1, 10000000) rr  -- указываем сколько лайков хотим сгенерить
        LOOP
        begin
            vRandomPostId := round(random() * 61516469)::bigint;  -- Случайным образом выбираем пост

            SELECT id, p.created_at, p.user_id
              into vPostId, vPostDate, vPostUserId
              FROM snet.posts p --TABLESAMPLE SYSTEM (0.1)
             where p.id = vRandomPostId;
              --limit 1;



            vUserId := 1 + round(random() * 305)::bigint;  -- Случайным обазом выбираем пользователя

            SELECT t.date_min
              into vLikeDate
              FROM snet.date_min_tmp t  TABLESAMPLE SYSTEM (0.1)  -- Генерируем дату лайка > дата поста
             where t.date_min > vPostDate
            limit 1;

            --raise notice 'vPostId=% ;vUserId=% ;vLikeDate=%', vPostId, vUserId, vLikeDate;
            if vPostId is not null and vLikeDate is not null and vPostUserId <> vUserId then  -- Проверям, что пользователь <> тому, кто написал пост
                                                                                              -- Остальные условия, думаю, можно убрать - остались от какой-то итерации
                insert into snet.likes_posts(post_id, user_id, created_at) values(vPostId, vUserId, vLikeDate);
            end if;
        exception
            when others then
              --raise notice '% %', SQLERRM, SQLSTATE;
              null;
        end;
    end loop;

  commit ;
end first_block $$;



select count(*) -- 176 448
  from snet.likes_posts