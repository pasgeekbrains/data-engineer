create procedure params_set_open(pparamsetid bigint)
    language plpgsql
as
$$
DECLARE
  vStatusId     ts.param_set.status_id%type;
begin
  begin
    select ps.status_id
      into STRICT vStatusId
      from ts.param_set ps
     where ps.id = pParamSetId;
  exception
    when no_data_found then
       raise exception 'Не удалось найти Набор параметров с Id= %', pParamSetId;
  end;

  if vStatusId = 1 then
    raise exception 'Набор параметров уже открыт';
  end if;


  update ts.param_set_elem e
    set unique_str = null
      , sql_ins_query = null
  where e.param_set_id = pParamSetId;

  delete from ts.time_series t
   where t.param_set_elem_id in (select e.id
                                   from ts.param_set_elem e
                                  where e.param_set_id = pParamSetId
                                );

  update ts.param_set p
     set unique_str = null
       , status_id = 1
   where p.id = pParamSetId;

end
$$;

alter procedure params_set_open(bigint) owner to admin;

