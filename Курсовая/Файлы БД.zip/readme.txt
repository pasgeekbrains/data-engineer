Курсовая в PG_Sql

1. Необходимая для курсовой часть от snet - snet.sql (Пользователи, Посты, Лайки к постам)
2. Курсовая: Временные ряды - схема ts - ts.sql (Все таблицы есть в ER схеме - https://github.com/pasgeekbrains/data-engineer/tree/master/Курсовая (нужно нажать на слово "тут"))
3. Функции и Процедуры, которые потребовались для курсовой: get_sql_ins_query, params_set_open, params_set_close  (они приложены в папке)