create function get_sql_ins_query(pparamsetelemid bigint) returns text
    language plpgsql
as
$$
DECLARE
  vSqlInsert text :=
      '
       insert into ts.time_series
       (
        param_set_elem_id,
        time_point,
       ';
  vSqlSelect text :=
      '
       select ' || pParamsEtelemId || ' as param_set_elem_id,' || chr(10);

  vSqlFrom    text;
  vSqlGroupBy text;
  vIndicator    ts.param_set.indicator%type;
  vTimePoint    ts.param_set.time_point%type;
  vTimePointFmt ts.param_set.time_point_fmt%type;
  vSqlQuery     ts.param_set.sql_query%type;
  vStatusId     ts.param_set.status_id%type;
  vParamSetId   ts.param_set.id%type;


  f_agg_row record;
  f_row     record;

begin


  begin
    select ps.indicator, ps.time_point, ps.time_point_fmt, ps.sql_query, ps.status_id, ps.id
      into STRICT vIndicator, vTimePoint, vTimePointFmt, vSqlQuery, vStatusId, vParamSetId
      from ts.param_set_elem pse
         , ts.param_set ps
     where pse.id = pParamSetElemId
       and ps.id = pse.param_set_id;
  exception
    when no_data_found then
       raise exception 'Не удалось найти элемент набора параметров с Id= %', pParamSetElemId;
  end;
/*
  if vStatusId not in (2) then
    raise exception 'Набор параметров не доступен к использованию, изменить его статус';
  end if;
*/
  vSqlFrom := '('|| chr(10) || vSqlQuery || chr(10) || ') k '|| chr(10);

  vSqlSelect := vSqlSelect || 'date_trunc(''' || vTimePointFmt || ''', ' || vTimePoint || ')::timestamp as time_point,' || chr(10);
  vSqlGroupBy := 'date_trunc(''' || vTimePointFmt || ''', ' || vTimePoint || ')::timestamp,' || chr(10);


  for f_agg_row in
    select t.id || ',' || chr(10) as ts_field_name
         , replace(coalesce(f.field_sql,'-1'), '@Indicator', vIndicator) || ' as ' || t.id || ',' || chr(10) as field_sql
      from ts.time_series_field_agg t
           left join ts.param_set_field_agg f on (f.param_set_id = vParamSetId and f.time_series_field_agg_id = t.id)
  loop
    vSqlInsert := vSqlInsert || f_agg_row.ts_field_name;
    vSqlSelect := vSqlSelect || f_agg_row.field_sql;
  end loop;


  for f_row in
    select f.time_series_field_id || ',' || chr(10) as ts_field_name
         , f.field_name || ',' || chr(10) as field_sql
      from ts.param_set_elem_field as fe
           join ts.param_set_field f on (f.id = fe.param_set_field_id)
     where fe.param_set_elem_id = pParamSetElemId

  loop
    vSqlInsert := vSqlInsert || f_row.ts_field_name;
    vSqlSelect := vSqlSelect || f_row.field_sql;
    vSqlGroupBy := vSqlGroupBy || f_row.field_sql;
  end loop;
  vSqlInsert := rtrim(vSqlInsert, ',' || chr(10)) || ')';
  vSqlSelect := rtrim(vSqlSelect, ',' || chr(10)) || chr(10);
  vSqlGroupBy := rtrim(vSqlGroupBy, ',' || chr(10));

  return vSqlInsert || vSqlSelect || ' from ' || chr(10) || vSqlFrom || 'group by ' || vSqlGroupBy;
end
$$;

alter function get_sql_ins_query(bigint) owner to admin;

